document.addEventListener('DOMContentLoaded', () => {
    const contactForm = document.getElementById('contactForm');
    const statusMessage = document.getElementById('statusMessage');

    if (contactForm) {
        contactForm.addEventListener('submit', (e) => {
            e.preventDefault();
            
            const nombre = document.getElementById('nombre').value;
            const email = document.getElementById('email').value;
            
            if (nombre && email) {
                statusMessage.textContent = `¡Gracias por tu mensaje, ${nombre}! Nos pondremos en contacto pronto.`;
                statusMessage.classList.remove('hidden');
                contactForm.reset();
                
                setTimeout(() => {
                    statusMessage.classList.add('hidden');
                }, 4000);
            }
        });
    }
});
