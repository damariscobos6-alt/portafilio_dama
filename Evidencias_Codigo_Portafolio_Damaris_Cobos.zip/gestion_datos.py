# Script de Automatización y Gestión de Datos
# Autor: Damaris Cobos

import json
from datetime import datetime

class GestorProyectos:
    def __init__(self, nombre_archivo="proyectos.json"):
        self.nombre_archivo = nombre_archivo
        self.proyectos = []

    def agregar_proyecto(self, titulo, tecnologia, estado="En Desarrollo"):
        nuevo_proyecto = {
            "id": len(self.proyectos) + 1,
            "titulo": titulo,
            "tecnologia": tecnologia,
            "estado": estado,
            "fecha_creacion": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        }
        self.proyectos.append(nuevo_proyecto)
        print(f"[+] Proyecto '{titulo}' registrado exitosamente.")

    def guardar_en_json(self):
        try:
            with open(self.nombre_archivo, 'w', encoding='utf-8') as file:
                json.dump(self.proyectos, file, indent=4, ensure_ascii=False)
            print(f"[✓] Datos guardados en {self.nombre_archivo}")
        except Exception as e:
            print(f"[X] Error al guardar datos: {e}")

    def mostrar_resumen(self):
        print("\n=== RESUMEN DE PROYECTOS REGISTRADOS ===")
        for p in self.proyectos:
            print(f"ID: {p['id']} | Título: {p['titulo']} | Tech: {p['tecnologia']} | Estado: {p['estado']}")

if __name__ == "__main__":
    gestor = GestorProyectos()
    gestor.agregar_proyecto("Maquetación Web Front-End", "HTML5/CSS3/JavaScript", "Completado")
    gestor.agregar_proyecto("Base de Datos Relacional", "SQL / Microsoft Access", "Completado")
    gestor.agregar_proyecto("Script de Automatización Backend", "Python", "Completado")
    
    gestor.mostrar_resumen()
    gestor.guardar_en_json()
