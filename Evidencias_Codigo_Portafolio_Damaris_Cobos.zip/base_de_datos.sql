-- Base de Datos Relacional de Ejemplo: Sistema de Gestión de Proyectos
-- Desarrollado por: Damaris Cobos

CREATE TABLE estudiantes (
    estudiante_id INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(100) NOT NULL,
    apellido VARCHAR(100) NOT NULL,
    email VARCHAR(150) UNIQUE NOT NULL,
    fecha_registro DATE DEFAULT (CURRENT_DATE)
);

CREATE TABLE proyectos (
    proyecto_id INT PRIMARY KEY AUTO_INCREMENT,
    titulo VARCHAR(150) NOT NULL,
    descripcion TEXT,
    fecha_inicio DATE,
    estudiante_id INT,
    FOREIGN KEY (estudiante_id) REFERENCES estudiantes(estudiante_id) ON DELETE CASCADE
);

CREATE TABLE tareas (
    tarea_id INT PRIMARY KEY AUTO_INCREMENT,
    proyecto_id INT,
    descripcion_tarea VARCHAR(255) NOT NULL,
    estado VARCHAR(50) DEFAULT 'Pendiente',
    FOREIGN KEY (proyecto_id) REFERENCES proyectos(proyecto_id) ON DELETE CASCADE
);

-- Insertar Datos de Prueba
INSERT INTO estudiantes (nombre, apellido, email) 
VALUES ('Damaris', 'Cobos', 'damaris@ejemplo.com');

INSERT INTO proyectos (titulo, descripcion, fecha_inicio, estudiante_id) 
VALUES ('Portafolio Web', 'Desarrollo de sitio web responsivo en HTML/CSS/JS', '2026-03-01', 1);

INSERT INTO tareas (proyecto_id, descripcion_tarea, estado) 
VALUES (1, 'Diseñar maquetación responsiva', 'Completado'),
       (1, 'Integrar scripts de interacción', 'En Proceso');

-- Consulta para Generar Reporte de Proyectos y Tareas
SELECT 
    e.nombre AS Estudiante,
    p.titulo AS Proyecto,
    t.descripcion_tarea AS Tarea,
    t.estado AS Estado
FROM estudiantes e
JOIN proyectos p ON e.estudiante_id = p.estudiante_id
JOIN tareas t ON p.proyecto_id = t.proyecto_id;
